package repositories;

import common.ExceptionMessages;
import models.players.Player;

public class PlayerRepository extends RepositoryImpl<Player> {

    @Override
    public void add(Player model) {
        if (model == null) {
            throw new NullPointerException(ExceptionMessages.INVALID_PLAYER_REPOSITORY);
        }
        super.add(model);
    }

    @Override
    public Player findByName(String name) {
        for (Player player : this.getModels()) {
            if (player.getUsername().equals(name)) {
                return player;
            }
        }
        return null;
    }
}
