package repositories;

import common.ExceptionMessages;
import models.guns.Gun;

import java.util.List;

public class GunRepository extends RepositoryImpl<Gun> {

    @Override
    public void add(Gun model) {
        if (model == null) {
            throw new NullPointerException(ExceptionMessages.INVALID_GUN_REPOSITORY);
        }
        super.add(model);
    }

    @Override
    public Gun findByName(String name) {
        for (Gun gun : this.getModels()) {
            if (gun.getName().equals(name)) {
                return gun;
            }
        }
        return null;
    }
}
