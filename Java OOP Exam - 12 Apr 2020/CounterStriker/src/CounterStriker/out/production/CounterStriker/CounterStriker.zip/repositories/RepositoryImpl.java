package repositories;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public abstract class RepositoryImpl<T> implements Repository<T> {
    private List<T> items;

    protected RepositoryImpl() {
        this.items = new ArrayList<>();
    }

    @Override
    public Collection<T> getModels() {
        return this.items;
    }

    @Override
    public void add(T model) {
        this.items.add(model);
    }

    @Override
    public boolean remove(T model) {
        return this.items.remove(model);
    }

    @Override
    public T findByName(String name) {
        return null;
    }
}
