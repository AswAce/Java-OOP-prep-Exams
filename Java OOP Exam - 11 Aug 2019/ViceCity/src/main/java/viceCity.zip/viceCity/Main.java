package viceCity;

import viceCity.core.ControllerImp;
import viceCity.core.EngineImpl;
import viceCity.core.interfaces.Controller;
import viceCity.core.interfaces.Engine;

public class Main {
    public static void main(String[] args) {
        Controller controller = new  ControllerImp();
        Engine engine = new EngineImpl(controller);
        engine.run();


//        Player player = new MainPlayer();
//        Player player2 = new CivilPlayer("Acho");
//        Player player3 = new CivilPlayer("Acho2");
//        Player player4 = new CivilPlayer("Acho3");
//        Gun gun = new Rifle("Storm");
//        Gun gun2 = new Pistol("Ace");
//        Gun gun3 = new Pistol("Ace2");
//        Gun gun4 = new Pistol("Ace3");
//        ArrayList<Player> players = new ArrayList<>();
//        players.add(player2);
//        players.add(player3);
////        players.add(player4);
//        player.getGunRepository().add(gun);
//        player.getGunRepository().add(gun2);
//        player.getGunRepository().add(gun3);
//        player.getGunRepository().add(gun4);
//        GangNeighbourhood gangNeighbourhood = new GangNeighbourhood();
//        gangNeighbourhood.action(player, players);
//        System.out.println();
    }
}
