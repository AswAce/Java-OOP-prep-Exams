package santasWorkshop.common;

public enum Command {
    AddDwarf,
    AddPresent,
    AddInstrumentToDwarf,
    CraftPresent,
    Report,
    Exit,
}
