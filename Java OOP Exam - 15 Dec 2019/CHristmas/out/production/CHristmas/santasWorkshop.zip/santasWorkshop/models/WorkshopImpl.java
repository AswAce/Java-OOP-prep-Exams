package santasWorkshop.models;

public class WorkshopImpl implements Workshop {

    @Override
    public void craft(Present present, Dwarf dwarf) {
        if (dwarf.canWork()) {
            while (!present.isDone() && dwarf.canWork() && !dwarf.getInstruments().isEmpty()) {
                for (Instrument instrument : dwarf.getInstruments()) {
                    while (!instrument.isBroken()) {
                        instrument.use();
                        dwarf.work();
                        present.getCrafted();
                    }
                }

            }
        }
    }
}
