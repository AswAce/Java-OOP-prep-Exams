package heroRepository;

import static org.junit.Assert.*;

public class ItemTest {

}