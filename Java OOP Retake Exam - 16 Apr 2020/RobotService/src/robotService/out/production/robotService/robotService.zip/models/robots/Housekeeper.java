package models.robots;
public class Housekeeper extends BaseRobot {
    public Housekeeper(String name, int energy, int happiness, int productionTime) {
        super(name, energy, happiness, productionTime);
    }
}
