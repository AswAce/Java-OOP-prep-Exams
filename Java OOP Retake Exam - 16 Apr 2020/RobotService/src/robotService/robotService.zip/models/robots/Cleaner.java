package models.robots;

public class Cleaner extends BaseRobot {
    public Cleaner(String name, int energy, int happiness, int productionTime) {
        super(name, energy, happiness, productionTime);
    }
}
