package common;

import core.interfaces.ManagerController;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class CommandExeciution implements Runnable {
    private  ManagerController managerController;
    private Scanner scanner;

    public CommandExeciution(ManagerController managerController, Scanner scanner) {
        this.managerController = managerController;
        this.scanner = scanner;
    }


    @Override
    public void run() {
        this.scanner.nextLine();
        while (!this.scanner.nextLine().equals("Exit")) {
            String[] token = this.scanner.nextLine().split("\\s+");
            switch (token[0]) {
                case "AddPlayer":
                    try {
                        System.out.println(this.managerController.addPlayer(token[1], token[2]));
                    } catch (ClassNotFoundException | InstantiationException | InvocationTargetException | IllegalAccessException | NoSuchMethodException e) {
                        e.printStackTrace();
                    }
                    break;
                case "AddCard":
                    try {
                        System.out.println(this.managerController.addCard(token[1], token[2]));
                    } catch (ClassNotFoundException | InstantiationException | InvocationTargetException | IllegalAccessException | NoSuchMethodException e) {
                        e.printStackTrace();
                    }
                    ;
                    break;

                case "AddPlayerCard":
                    System.out.println(this.managerController.addPlayerCard(token[1], token[2]));
                    break;
                case "Fight":
                    System.out.println(this.managerController.fight(token[1], token[2]));
                    break;
                case "Report":
                    System.out.println(this.managerController.report());
                    break;

            }
            scanner.nextLine();
        }

    }
}
