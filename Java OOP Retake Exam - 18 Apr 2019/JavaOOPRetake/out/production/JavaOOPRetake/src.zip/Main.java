import common.CommandExeciution;
import core.ManagerControllerImpl;
import core.interfaces.ManagerController;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Scanner scanner = new Scanner(System.in);
        ManagerController managerController = new ManagerControllerImpl();
//        CommandExeciution commandExeciution = new CommandExeciution(managerController, scanner);
//        commandExeciution.run();
        String command = scanner.nextLine();
        while (!command.equals("Exit")) {
            String[] token = command.split("\\s+");
            switch (token[0]) {
                case "AddPlayer":
                    System.out.println(managerController.addPlayer(token[1], token[2]));

                    break;
                case "AddCard":
                    System.out.println(managerController.addCard(token[1], token[2]));

                    ;
                    break;

                case "AddPlayerCard":
                    System.out.println(managerController.addPlayerCard(token[1], token[2]));
                    break;
                case "Fight":
                    System.out.println(managerController.fight(token[1], token[2]));
                    break;
                case "Report":
                    System.out.println(managerController.report());
                    break;

            }
            command = scanner.nextLine();
        }
    }
}
