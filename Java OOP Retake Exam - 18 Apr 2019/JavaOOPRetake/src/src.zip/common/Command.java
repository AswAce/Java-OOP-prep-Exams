package common;

public enum Command {
    AddPlayer,
    AddCard,
    AddPlayerCard,
    Fight,
    Report,
    Exit
}
